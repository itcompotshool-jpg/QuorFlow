
from components.internet import InternetManager

def main():
    manager = InternetManager()
    
    # Проверка соединения
    if manager.test_connectivity():
        # Работа с API
        data = manager.fetch_data("wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4", "data")
        
        # Скачивание файла
        success = manager.internet.download_file(
            "http://QuorFlow.comf",
            "not_dowland"
        )

if __name__ == "__main__":
    main()