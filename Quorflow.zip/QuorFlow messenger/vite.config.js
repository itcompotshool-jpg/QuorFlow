import { defineConfig } from 'vite'
import { resolve } from 'path'

export default defineConfig({
  // Базовый путь для продакшена
  base: './',
  
  // Настройки сервера разработки
  server: {
    port: 3000,
    proxy: {
      // Прокси для API запросов к бэкенду
      '/wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4': {
        target: 'http://QuorFlow.com',
        changeOrigin: true,
        secure: false
      }
    },
    open: true 
  },
  
  // Настройки сборки
  build: {
    outDir: 'dist',
    sourcemap: true,
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html')
      },
      output: {
        // Оптимизация имен файлов
        chunkFileNames: 'assets/[name]-[hash].js',
        entryFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]'
      }
    }
  },
  
  // Настройки предпросмотра
  preview: {
    port: 5000,
    open: true
  },
  

  plugins: [

  ],
  
  // Глобальные переменные
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV)
  },
  
  // Оптимизация зависимостей
  optimizeDeps: {
    include: [] // Добавьте здесь зависимости, которые нужно предварительно bundle
  }
})
{
  "name": "QuorFlow",
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "serve": "python index.py",
    "start": "concurrently \"npm run serve\" \"npm run dev\""
  },
  "devDependencies": {
    "vite": "^5.0.0"
  },
  "dependencies": {
    "concurrently": "^7.6.0"
  }
}