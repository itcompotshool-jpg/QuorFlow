export class ChatWindow {
  constructor(container) {
    this.container = container;
    this.currentChat = null;
    this.messages = [];
  }

  render() {
    if (!this.currentChat) {
      this.container.innerHTML = `
        <div class="chat-window">
          <div class="messages-container" style="display: flex; align-items: center; justify-content: center;">
            <div style="text-align: center; color: var(--text-secondary);">
              <h3>Выберите чат для начала общения</h3>
              <p>QuorFlow - минималистичный и мощный мессенджер</p>
            </div>
          </div>
        </div>
      `;
      return;
    }

    this.container.innerHTML = `
      <div class="chat-window">
        <div class="chat-header">
          <div class="chat-title">
            <h2>${this.currentChat.name}</h2>
            <p>${this.currentChat.status === 'online' ? 'В сети' : 'Не в сети'}</p>
          </div>
          <div class="chat-actions">
            <button class="icon-button" title="Поиск">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M21 21L16.514 16.506L21 21ZM19 10.5C19 15.194 15.194 19 10.5 19C5.806 19 2 15.194 2 10.5C2 5.806 5.806 2 10.5 2C15.194 2 19 5.806 19 10.5Z" 
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
            <button class="icon-button" title="Настройки">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" 
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M19.4 15C19.2669 15.3044 19.201 15.6343 19.2 16C19.2 16.7956 19.5161 17.5587 20.075 18.125C20.6339 18.6913 21.3913 19.0096 22.18 19.0096C22.5288 19.0096 22.875 18.95 23.2 18.84L22.5 21.5L19.4 20.8C19.29 21.125 19.2304 21.4712 19.2304 21.82C19.2304 22.6087 19.5487 23.3661 20.115 23.925C20.6813 24.4839 21.4444 24.8 22.24 24.8C23.0356 24.8 23.7987 24.4839 24.365 23.925C24.9313 23.3661 25.2475 22.6087 25.2475 21.82C25.2475 21.0313 24.9313 20.2739 24.365 19.715C23.7987 19.1561 23.0356 18.84 22.24 18.84C21.8743 18.84 21.5444 18.9059 21.24 19.04L22.08 16.38L19.4 15Z" 
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="messages-container" id="messagesContainer">
          ${this.messages.map(message => this.renderMessage(message)).join('')}
        </div>
        <div class="message-input-container">
          <div class="message-input-wrapper">
            <textarea 
              class="message-input" 
              placeholder="Введите сообщение..." 
              rows="1"
              id="messageInput"
            ></textarea>
            <button class="send-button" id="sendButton" disabled>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M22 2L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    this.attachEventListeners();
    this.scrollToBottom();
  }

  renderMessage(message) {
    const isSent = message.sender === 'user';
    const senderName = isSent ? 'Вы' : this.currentChat.name;
    
    return `
      <div class="message ${isSent ? 'sent' : 'received'}">
        ${!isSent ? `<div class="message-sender">${senderName}</div>` : ''}
        <div class="message-text">${message.text}</div>
        <div class="message-time">${this.formatTime(message.timestamp)}</div>
      </div>
    `;
  }

  formatTime(timestamp) {
    return new Date(timestamp).toLocaleTimeString('ru-RU', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  }

  attachEventListeners() {
    const messageInput = this.container.querySelector('#messageInput');
    const sendButton = this.container.querySelector('#sendButton');

    if (messageInput && sendButton) {
      messageInput.addEventListener('input', () => {
        sendButton.disabled = !messageInput.value.trim();
        
        // Auto-resize textarea
        messageInput.style.height = 'auto';
        messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
      });

      messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.sendMessage();
        }
      });

      sendButton.addEventListener('click', () => {
        this.sendMessage();
      });
    }
  }

  sendMessage() {
    const messageInput = this.container.querySelector('#messageInput');
    const text = messageInput.value.trim();
    
    if (!text) return;

    const message = {
      id: Date.now().toString(),
      text: text,
      sender: 'user',
      timestamp: new Date().toISOString()
    };

    this.addMessage(message);
    messageInput.value = '';
    messageInput.style.height = 'auto';
    this.container.querySelector('#sendButton').disabled = true;

    // Simulate reply after 1-3 seconds
    setTimeout(() => {
      const replies = [
        'Привет! Как дела?',
        'Интересное сообщение!',
        'Спасибо за информацию!',
        'Давайте обсудим это подробнее',
        'Отличная идея!',
        'Я думаю, это хороший план'
      ];
      
      const reply = {
        id: Date.now().toString(),
        text: replies[Math.floor(Math.random() * replies.length)],
        sender: 'other',
        timestamp: new Date().toISOString()
      };
      
      this.addMessage(reply);
    }, 1000 + Math.random() * 2000);
  }

  addMessage(message) {
    this.messages.push(message);
    this.render();
    
    // Notify parent component about new message
    if (typeof this.onNewMessage === 'function') {
      this.onNewMessage(this.currentChat.id, message);
    }
  }

  scrollToBottom() {
    const container = this.container.querySelector('#messagesContainer');
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }

  setCurrentChat(chat) {
    this.currentChat = chat;
    this.messages = chat.messages || [];
    this.render();
  }

  clear() {
    this.currentChat = null;
    this.messages = [];
    this.render();
  }
}