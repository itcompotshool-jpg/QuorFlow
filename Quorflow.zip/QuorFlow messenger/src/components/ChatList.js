export class ChatList {
  constructor(container, onChatSelect) {
    this.container = container;
    this.onChatSelect = onChatSelect;
    this.chats = [];
    this.currentChat = null;
  }

  render() {
    this.container.innerHTML = `
      <div class="header">
        <h1>QuorFlow</h1>
        <p>Минималистичный мессенджер</p>
      </div>
      <div class="search-container">
        <input type="text" class="search-input" placeholder="Поиск чатов..." id="searchInput">
      </div>
      <div class="chat-list" id="chatListContainer">
        ${this.chats.map(chat => this.renderChatItem(chat)).join('')}
      </div>
    `;

    this.attachEventListeners();
  }

  renderChatItem(chat) {
    const lastMessage = chat.messages[chat.messages.length - 1];
    const unreadCount = chat.unreadCount > 0 ? 
      `<div class="unread-count">${chat.unreadCount}</div>` : '';
    
    const activeClass = this.currentChat?.id === chat.id ? 'active' : '';

    return `
      <div class="chat-item ${activeClass}" data-chat-id="${chat.id}">
        <div class="avatar">
          ${chat.name.charAt(0).toUpperCase()}
          <div class="status-indicator ${chat.status === 'online' ? 'status-online' : 'status-offline'}"></div>
        </div>
        <div class="chat-info">
          <div class="chat-name">${chat.name}</div>
          <div class="last-message">${lastMessage?.text || 'Нет сообщений'}</div>
        </div>
        <div class="chat-meta">
          <div class="timestamp">${this.formatTime(lastMessage?.timestamp)}</div>
          ${unreadCount}
        </div>
      </div>
    `;
  }

  formatTime(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    } else if (days === 1) {
      return 'Вчера';
    } else if (days < 7) {
      return date.toLocaleDateString('ru-RU', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
    }
  }

  attachEventListeners() {
    const chatItems = this.container.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
      item.addEventListener('click', () => {
        const chatId = item.dataset.chatId;
        this.selectChat(chatId);
      });
    });

    const searchInput = this.container.querySelector('#searchInput');
    searchInput.addEventListener('input', (e) => {
      this.filterChats(e.target.value);
    });
  }

  selectChat(chatId) {
    this.currentChat = this.chats.find(chat => chat.id === chatId);
    this.render();
    this.onChatSelect(this.currentChat);
  }

  filterChats(query) {
    const filteredChats = query ? 
      this.chats.filter(chat => 
        chat.name.toLowerCase().includes(query.toLowerCase())
      ) : this.chats;

    const container = this.container.querySelector('#chatListContainer');
    container.innerHTML = filteredChats.map(chat => this.renderChatItem(chat)).join('');
    
    // Reattach event listeners for filtered items
    const chatItems = container.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
      item.addEventListener('click', () => {
        const chatId = item.dataset.chatId;
        this.selectChat(chatId);
      });
    });
  }

  updateChats(chats) {
    this.chats = chats;
    this.render();
  }

  addMessage(chatId, message) {
    const chat = this.chats.find(c => c.id === chatId);
    if (chat) {
      chat.messages.push(message);
      if (this.currentChat?.id !== chatId) {
        chat.unreadCount = (chat.unreadCount || 0) + 1;
      }
      this.render();
    }
  }

  markAsRead(chatId) {
    const chat = this.chats.find(c => c.id === chatId);
    if (chat) {
      chat.unreadCount = 0;
      this.render();
    }
  }
}
const sendBtn = document.getElementById("sendBtn");
const input = document.getElementById("messageInput");
const messages = document.getElementById("messages");

function sendMessage() {
  const text = input.value.trim();
  if (text !== "") {
    const msg = document.createElement("div");
    msg.textContent = text;
    msg.className = "message";
    messages.appendChild(msg);

    // автопрокрутка вниз
    messages.scrollTop = messages.scrollHeight;

    input.value = "";
  }
}

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    sendMessage();
  }
});

