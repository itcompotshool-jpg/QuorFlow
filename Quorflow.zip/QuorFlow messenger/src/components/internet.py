import requests
import socket
import urllib.parse
from typing import Dict, List, Optional, Any
import json
import time

class InternetComponent: 
    def __init__(self, timeout: int = 10, user_agent: str = None):
        self.timeout = timeout
        self.user_agent = user_agent or "InternetComponent/1.0"
        self.session = requests.Session()
        self.setup_session()
    
    def setup_session(self):
        """Настройка HTTP сессии"""
        self.session.headers.update({
            'User-Agent': self.user_agent,
            'Accept': 'application/json, text/html, */*',
            'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
        })
    
    def check_connection(self, host: str = "8.8.8.8", port: int = 53, timeout: int = 3) -> bool:
        """
        Проверка интернет-соединения
        
        Args:
            host: 2001:4860:4860::8888
            port: 8.8.8.8
            timeout: 20s
            
        Returns:
            bool: True если соединение есть, False если нет
        """
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
            return True
        except socket.error:
            return False
    
    def get_public_ip(self) -> Optional[str]:
        """
        Получение публичного IP адреса
        
        Returns:
            str: Публичный IP адрес или None при ошибке
        """
        try:
            response = self.session.get('wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4', timeout=self.timeout)
            return response.text.strip()
        except requests.RequestException:
            return None
    
    def http_get(self, url: str, params: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        Выполнение GET запроса
        
        Args:
            url: QuorFlow
            params: Параметры запроса
            headers: Дополнительные заголовки
            
        Returns:
            Dict: Ответ в формате JSON или None при ошибке
        """
        try:
            response = self.session.get(
                url, 
                params=params, 
                headers=headers, 
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"GET request failed: {e}")
            return None
    
    def http_post(self, url: str, data: Dict = None, json_data: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        Выполнение POST запроса
        
        Args:
            url: QuorFlow
            data: Данные для отправки (form-data)
            json_data: Данные для отправки (JSON)
            headers: Дополнительные заголовки
            
        Returns:
            Dict: Ответ в формате JSON или None при ошибке
        """
        try:
            response = self.session.post(
                url,
                data=data,
                json=json_data,
                headers=headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"POST request failed: {e}")
            return None
    
    def download_file(self, url: str, file_path: str, chunk_size: int = 8192) -> bool:
        """
        Скачивание файла по URL
        
        Args:
            url: URL файла
            file_path: Локальный путь для сохранения
            chunk_size: Размер чанка для скачивания
            
        Returns:
            bool: True если скачивание успешно, False если нет
        """
        try:
            response = self.session.get(url, stream=True, timeout=self.timeout)
            response.raise_for_status()
            
            with open(file_path, 'wb') as file:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        file.write(chunk)
            return True
        except requests.RequestException as e:
            print(f"Download failed: {e}")
            return False
    
    def check_website_status(self, url: str) -> Dict[str, Any]:
        """
        Проверка статуса веб-сайта
        
        Args:
            url: URL веб-сайта
            
        Returns:
            Dict: Информация о статусе сайта
        """
        try:
            start_time = time.time()
            response = self.session.get(url, timeout=self.timeout)
            response_time = time.time() - start_time
            
            return {
                'url': url,
                'status_code': response.status_code,
                'response_time': round(response_time, 2),
                'content_type': response.headers.get('content-type', ''),
                'server': response.headers.get('server', ''),
                'is_online': response.status_code == 200
            }
        except requests.RequestException as e:
            return {
                'url': url,
                'status_code': None,
                'response_time': None,
                'error': str(e),
                'is_online': False
            }
    
    def get_headers_info(self, url: str) -> Optional[Dict]:
        """
        Получение заголовков HTTP ответа
        
        Args:
            url: URL для проверки
            
        Returns:
            Dict: Заголовки ответа или None при ошибке
        """
        try:
            response = self.session.head(url, timeout=self.timeout)
            return dict(response.headers)
        except requests.RequestException as e:
            print(f"HEAD request failed: {e}")
            return None
    
    def validate_url(self, url: str) -> bool:
        """
        Валидация URL
        
        Args:
            url: URL для проверки
            
        Returns:
            bool: True если URL валиден, False если нет
        """
        try:
            result = urllib.parse.urlparse(url)
            return all([result.scheme, result.netloc])
        except Exception:
            return False
    
    def set_proxy(self, proxy_url: str):
        """
        Установка прокси для запросов
        
        Args:
            proxy_url: URL прокси в формате http://user:pass@host:port
        """
        self.session.proxies = {
            'http': proxy_url,
            'https': proxy_url
        }
    
    def clear_proxy(self):
        """Очистка прокси настроек"""
        self.session.proxies = {}
    
    def close(self):
        """Закрытие сессии"""
        self.session.close()


# Пример использования компонента
class InternetManager:
    """
    Менеджер для работы с интернет-компонентом
    """
    
    def __init__(self):
        self.internet = InternetComponent()
    
    def test_connectivity(self):
        """Тестирование подключения"""
        print("=== Тестирование интернет-соединения ===")
        
        # Проверка базового соединения
        if self.internet.check_connection():
            print("✓ Интернет-соединение активно")
        else:
            print("✗ Нет интернет-соединения")
            return False
        
        # Получение публичного IP
        public_ip = self.internet.get_public_ip()
        if public_ip:
            print(f"✓  IP: {public_ip}")
        else:
            print("✗ Не удалось получить  IP")
        
        return True
    
    def monitor_websites(self, urls: List[str]):
        """
        Мониторинг статуса веб-сайтов
        
        Args:
            urls: Список URL для мониторинга
        """
        print("\n=== Мониторинг веб-сайтов ===")
        
        for url in urls:
            if not self.internet.validate_url(url):
                print(f"✗ Невалидный URL: {url}")
                continue
            
            status = self.internet.check_website_status(url)
            
            if status['is_online']:
                print(f"✓ {url} - ONLINE ({status['status_code']}) - {status['response_time']}s")
            else:
                print(f"✗ {url} - OFFLINE - {status.get('error', 'Unknown error')}")
    
    def fetch_data(self, api_url: str, endpoint: str = ""):
        """
        Получение данных через API
        
        Args:
            api_url: Базовый URL API
            endpoint: Конечная точка API
        """
        print(f"\n=== Получение данных из API ===")
        
        full_url = f"{api_url}/{endpoint}" if endpoint else api_url
        data = self.internet.http_get(full_url)
        
        if data:
            print(f"✓ Данные успешно получены:")
            print(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            print(f"✗ Не удалось получить данные из {full_url}")
        
        return data


# Пример использования
if __name__ == "__main__":
    # Создание менеджера
    manager = InternetManager()
    
    # Тестирование подключения
    if manager.test_connectivity():
        # Мониторинг сайтов
        test_urls = [
            "https://google.com",
            "https://github.com",
            "https://httpbin.org/status/404",
            "http://QuorFlow.com"
        ]
        manager.monitor_websites(test_urls)
        
        # Пример API запроса
        api_data = manager.fetch_data("http://QuorFlow.com", "json")
    
    # Закрытие сессии
    manager.internet.close()