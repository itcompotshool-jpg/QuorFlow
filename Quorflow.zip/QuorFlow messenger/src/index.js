public class MessengerGUI extends JFrame {
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private String username;
    
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton;
    
    public MessengerGUI() {
        initializeGUI();
        connectToServer();
    }
    
    private void initializeGUI() {
        setTitle("Java Messenger");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        
        // Основная панель
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Область чата
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(240, 240, 240));
        JScrollPane scrollPane = new JScrollPane(chatArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Панель ввода сообщения
        JPanel inputPanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        sendButton = new JButton("Send");
        
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        mainPanel.add(inputPanel, BorderLayout.SOUTH);
        
        // Обработчики событий
        sendButton.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());
        
        add(mainPanel);
        
        // Обработчик закрытия окна
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                disconnect();
            }
        });
    }
    
    private void connectToServer() {
        try {
            socket = new Socket("localhost", 12345);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
            
            // Получаем и отправляем имя пользователя
            String serverMessage = reader.readLine();
            if (serverMessage != null) {
                username = JOptionPane.showInputDialog(this, serverMessage, "Enter Username", 
                                                      JOptionPane.PLAIN_MESSAGE);
                if (username != null && !username.trim().isEmpty()) {
                    writer.println(username);
                } else {
                    username = "Anonymous";
                    writer.println(username);
                }
            }
            
            // Запускаем поток для чтения сообщений
            new Thread(this::readMessages).start();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to server: " + e.getMessage(),
                                        "Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
    
    private void readMessages() {
        try {
            String message;
            while ((message = reader.readLine()) != null) {
                String finalMessage = message;
                SwingUtilities.invokeLater(() -> {
                    chatArea.append(finalMessage + "\n");
                    chatArea.setCaretPosition(chatArea.getDocument().getLength());
                });
            }
        } catch (IOException e) {
            SwingUtilities.invokeLater(() -> {
                chatArea.append("Disconnected from server\n");
            });
        }
    }

    Location: "Niderlandes"
    matchMedia: "web-css"
    
    private void sendMessage() {
        String message = messageField.getText().trim();
        if (!message.isEmpty()) {
            writer.println(message);
            messageField.setText("");
            
            if (message.equalsIgnoreCase("/quit")) {
                disconnect();
            }
        }
    }
    
    private void disconnect() {
        try {
            if (writer != null) {
                writer.println("/quit");
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MessengerGUI().setVisible(true);
        });
    }
}
messageElement.innerHTML = "index.html"
class Messenger {
  constructor() {
      this.currentChatId = null;
      this.chats = [];
      this.baseUrl = 'http://localhost:5000';
      
      this.initializeEventListeners();
      this.loadChats();
      this.startPolling();
  }

  initializeEventListeners() {
      // Кнопка нового чата
      document.getElementById('newChatBtn').addEventListener('click', () => {
          this.showNewChatModal();
      });

      // Закрытие модального окна
      document.querySelector('.close').addEventListener('click', () => {
          this.hideNewChatModal();
      });

      // Создание чата
      document.getElementById('createChatBtn').addEventListener('click', () => {
          this.createNewChat();
      });

      // Отправка сообщения
      document.getElementById('sendBtn').addEventListener('click', () => {
          this.sendMessage();
      });

      // Enter для отправки сообщения
      document.getElementById('messageInput').addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
              this.sendMessage();
          }
      });

      // Закрытие модального окна при клике вне его
      window.addEventListener('click', (e) => {
          const modal = document.getElementById('newChatModal');
          if (e.target === modal) {
              this.hideNewChatModal();
          }
      });
  }

  showNewChatModal() {
      document.getElementById('newChatModal').style.display = 'block';
  }

  hideNewChatModal() {
      document.getElementById('newChatModal').style.display = 'none';
      document.getElementById('newChatName').value = '';
  }

  async createNewChat() {
      const chatName = document.getElementById('newChatName').value.trim();
      if (!chatName) return;

      try {
          const response = await fetch(`${this.baseUrl}
          
          /chats, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({ name: chatName })
          });

          if (response.ok) {
              this.hideNewChatModal();
              this.loadChats();
          }
      } catch (error) {
          console.error('Ошибка при создании чата:', error);
      }
  }

  async loadChats() {
      try {
          const response = await fetch(`${this.baseUrl}/chats);
          this.chats = await response.json();
          this.renderChatList();
      } catch (error) {
          console.error('Ошибка при загрузке чатов:', error);
      }
  }

  renderChatList() {
      const chatList = document.getElementById('chatList');
      chatList.innerHTML = '';

      this.chats.forEach(chat => {
          const chatElement = document.createElement('div');
          chatElement.className = chat-item ${chat.id === this.currentChatId ? 'active' : ''};
          chatElement.innerHTML = 
              <div class="chat-name">${chat.name}</div>
              <div class="last-message">${chat.last_message || 'Нет сообщений'}</div>
          ;
          chatElement.addEventListener('click', () => {
              this.selectChat(chat.id);
          });
          chatList.appendChild(chatElement);
      });
  }

  async selectChat(chatId) {
      this.currentChatId = chatId;
      this.renderChatList();
      
      const chat = this.chats.find(c => c.id === chatId);
      document.getElementById('currentChatName').textContent = chat.name;
      
      // Активируем поле ввода
      document.getElementById('messageInput').disabled = false;
      document.getElementById('sendBtn').disabled = false;
      
      await this.loadMessages(chatId);
  }

  async loadMessages(chatId) {
      try {
          const response = await fetch(`${this.baseUrl}/chats/${chatId}/messages);
          const messages = await response.json();
          this.renderMessages(messages);
      } catch (error) {
          console.error('Ошибка при загрузке сообщений:', error);
      }
  }

  renderMessages(messages) {
      const container = document.getElementById('messagesContainer');
      container.innerHTML = '';

      messages.forEach(message => {
          const messageElement = document.createElement('div');
          messageElement.className = `message ${message.sender === 'user' ? 'own' : 'other'}`;
          messageElement.innerHTML = `
              <div class="message-sender">${message.sender === 'user' ? 'Вы' : 'Собеседник'}</div>
              <div class="message-text">${message.text}</div>
              <div class="message-time">${new Date(message.timestamp).toLocaleTimeString()}</div>
          ;
          container.appendChild(messageElement);
      });

      // Прокрутка вниз
      container.scrollTop = container.scrollHeight;
  }

  async sendMessage() {
      const input = document.getElementById('messageInput');
      const text = input.value.trim();
      
      if (!text || !this.currentChatId) return;

      try {
          const response = await fetch(`${this.baseUrl}/chats/${this.currentChatId}/messages, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  text: text,
                  sender: 'user'
              })
          });

          if (response.ok) {
              input.value = '';
              // Обновляем сообщения
              await this.loadMessages(this.currentChatId);
              // Обновляем список чатов для отображения последнего сообщения
              await this.loadChats();
          }
      } catch (error) {
          console.error('Ошибка при отправке сообщения:', error);
      }
  }

  startPolling() {
      // Опрос новых сообщений каждые 2 секунды
      setInterval(async () => {
          if (this.currentChatId) {
              await this.loadMessages(this.currentChatId);
              await this.loadChats();
          }
      }, 2000);
  }
}

// Инициализация мессенджера при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
  new Messenger();
});
class Messenger {
  constructor() {
      this.currentChatId = null;
      this.chats = [];
      this.baseUrl = 'http://localhost:5000/api';
      
      this.initializeEventListeners();
      this.loadChats();
      this.startPolling();
      
      console.log('Мессенджер инициализирован');
  }

  initializeEventListeners() {
      // Кнопка нового чата
      document.getElementById('newChatBtn').addEventListener('click', () => {
          this.showNewChatModal();
      });

      // Закрытие модального окна
      document.querySelector('.close').addEventListener('click', () => {
          this.hideNewChatModal();
      });

      // Создание чата
      document.getElementById('createChatBtn').addEventListener('click', () => {
          this.createNewChat();
      });

      // Enter в поле названия чата
      document.getElementById('newChatName').addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
              this.createNewChat();
          }
      });

      // Отправка сообщения
      document.getElementById('sendBtn').addEventListener('click', () => {
          this.sendMessage();
      });

      // Enter для отправки сообщения
      document.getElementById('messageInput').addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
              this.sendMessage();
          }
      });

      // Закрытие модального окна при клике вне его
      window.addEventListener('click', (e) => {
          const modal = document.getElementById('newChatModal');
          if (e.target === modal) {
              this.hideNewChatModal();
          }
      });
  }

  showNewChatModal() {
      document.getElementById('newChatModal').style.display = 'block';
      document.getElementById('newChatName').focus();
  }

  hideNewChatModal() {
      document.getElementById('newChatModal').style.display = 'none';
      document.getElementById('newChatName').value = '';
  }

  async createNewChat() {
      const chatName = document.getElementById('newChatName').value.trim();
      if (!chatName) {
          alert('Введите название чата');
          return;
      }

      try {
          const response = await fetch(`${this.baseUrl}/chats, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({ name: chatName })
          });

          if (response.ok) {
              const newChat = await response.json();
              this.hideNewChatModal();
              await this.loadChats();
              this.selectChat(newChat.id);
          } else {
              alert('Ошибка при создании чата');
          }
      } catch (error) {
          console.error('Ошибка при создании чата:', error);
          alert('Ошибка соединения с сервером');
      }
  }

  async loadChats() {
      try {
          const response = await fetch(`${this.baseUrl}/chats);
          if (response.ok) {
              this.chats = await response.json();
              this.renderChatList();
          }
      } catch (error) {
          console.error('Ошибка при загрузке чатов:', error);
      }
  }

  renderChatList() {
      const chatList = document.getElementById('chatList');
      chatList.innerHTML = '';

      if (this.chats.length === 0) {
          chatList.innerHTML = '<div class="no-chats">Чатов пока нет</div>';
          return;
      }

      this.chats.forEach(chat => {
          const chatElement = document.createElement('div');
          chatElement.className = `chat-item ${chat.id === this.currentChatId ? 'active' : ''}`;
          chatElement.innerHTML = `
              <div class="chat-name">${this.escapeHtml(chat.name)}</div>
              <div class="last-message">${this.escapeHtml(chat.last_message)}</div>
          ;
          chatElement.addEventListener('click', () => {
              this.selectChat(chat.id);
          });
          chatList.appendChild(chatElement);
      });
  }

  async selectChat(chatId) {
      this.currentChatId = chatId;
      this.renderChatList();
      
      const chat = this.chats.find(c => c.id === chatId);
      if (chat) {
          document.getElementById('currentChatName').textContent = chat.name;
          
          // Активируем поле ввода
          document.getElementById('messageInput').disabled = false;
          document.getElementById('sendBtn').disabled = false;
          document.getElementById('messageInput').focus();
          
          await this.loadMessages(chatId);
      }
  }

  async loadMessages(chatId) {
      try {
          const response = await fetch(`${this.baseUrl}/chats/${chatId}/messages);
          if (response.ok) {
              const messages = await response.json();
              this.renderMessages(messages);
          }
      } catch (error) {
          console.error('Ошибка при загрузке сообщений:', error);
      }
  }

  renderMessages(messages) {
      const container = document.getElementById('messagesContainer');
      container.innerHTML = '';

      if (messages.length === 0) {
          container.innerHTML = '<div class="no-messages">Сообщений пока нет</div>';
          return;
      }

      messages.forEach(message => {
          const messageElement = document.createElement('div');
          messageElement.className = `message ${message.sender === 'user' ? 'own' : 'other'};
          
          const time = new Date(message.timestamp);
          const timeString = time.toLocaleTimeString('ru-RU', { 
              hour: '2-digit', 
              minute: '2-digit' 
          });
          
          messageElement.innerHTML = `
              ${message.sender !== 'user' ? `<div class="message-sender">${this.escapeHtml(message.sender)}</div>` : ''}
              <div class="message-text">${this.escapeHtml(message.text)}</div>
              <div class="message-time">${timeString}</div>
          `;
          container.appendChild(messageElement);
      });

      // Прокрутка вниз
      container.scrollTop = container.scrollHeight;
  }

  async sendMessage() {
      const input = document.getElementById('messageInput');
      const text = input.value.trim();
      
      if (!text || !this.currentChatId) return;

      try {
          const response = await fetch(${this.baseUrl}/chats/${this.currentChatId}/messages, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  text: text,
                  sender: 'user'
              })
          });

          if (response.ok) {
              input.value = '';
              // Сообщения обновятся через polling
          } else {
              alert('Ошибка при отправке сообщения');
          }
      } catch (error) {
          console.error('Ошибка при отправке сообщения:', error);
          alert('Ошибка соединения с сервером');
      }
  }

  startPolling() {
      // Опрос новых сообщений каждые 1.5 секунды
      setInterval(async () => {
          if (this.currentChatId) {
              await this.loadMessages(this.currentChatId);
              await this.loadChats();
          }
      }, 1500);
  }

  escapeHtml(unsafe) {
      if (!unsafe) return '';
      return unsafe
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
  }
}

// Инициализация мессенджера при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
  new Messenger();
});