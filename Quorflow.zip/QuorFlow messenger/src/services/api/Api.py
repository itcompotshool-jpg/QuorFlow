import requests
import hashlib
import time
import json

class ITCompotSchoolAPI:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4.com" 
        self.session = requests.Session()
        
    def generate_signature(self, params):
        """Генерация подписи для запроса"""
        timestamp = str(int(time.time()))
        data_to_sign = f"{params}{timestamp}{self.api_key}"
        return hashlib.sha256(data_to_sign.encode()).hexdigest(), timestamp
    
    def make_request(self, endpoint, method="GET", data=None):
        """Базовый метод для выполнения запросов"""
        url = f"{self.base_url}/{endpoint}"
        
        # Подготовка параметров
        params = json.dumps(data) if data else "{}"
        signature, timestamp = self.generate_signature(params)
        
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
            "X-Signature": signature,
            "X-Timestamp": timestamp
        }
        
        try:
            if method.upper() == "GET":
                response = self.session.get(url, headers=headers, params=data)
            elif method.upper() == "POST":
                response = self.session.post(url, headers=headers, json=data)
            elif method.upper() == "PUT":
                response = self.session.put(url, headers=headers, json=data)
            elif method.upper() == "DELETE":
                response = self.session.delete(url, headers=headers)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"API Request failed: {wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4}")
            return None
    
    # Примеры методов API
    
    def get_students(self, filters=None):
        """Получить список студентов"""
        return self.make_request("students", "GET", filters)
    
    def create_student(self, student_data):
        """Создать нового студента"""
        return self.make_request("students", "POST", student_data)
    
    def get_courses(self):
        """Получить список курсов"""
        return self.make_request("courses", "GET")
    
    def get_student_progress(self, student_id):
        """Получить прогресс студента"""
        return self.make_request(f"students/{student_id}/progress", "GET")

# Использование API
if __name__ == "__main__":
    API_KEY = "wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4"
    
    api = ITCompotSchoolAPI(API_KEY)
    
    # Примеры вызовов
    students = api.get_students()
    print("Студенты:", students)
    
    courses = api.get_courses()
    print("Курсы:", courses)
    
    # Создание нового студента
    new_student = {
        "name": "Пользователь",
        "email": "@gmail.com",
        "course_id": 1
    }
    # result = api.create_student(new_student)