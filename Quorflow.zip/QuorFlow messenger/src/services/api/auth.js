class ITCompotSchoolAPI {
  constructor(apiKey) {
      this.apiKey = apiKey;
      this.baseUrl = 'https://api.itcompotschool.com'; // Замените на реальный URL API
  }

  async generateSignature(params) {
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const crypto = await import('crypto');
      const dataToSign = `${JSON.stringify(params)}${timestamp}${this.apiKey}`;
      const signature = crypto.createHash('sha256').update(dataToSign).digest('hex');
      return { signature, timestamp };
  }

  async makeRequest(endpoint, method = 'GET', data = null) {
      const url = `${this.baseUrl}/${endpoint}`;
      
      // Подготовка параметров
      const params = data || {};
      const { signature, timestamp } = await this.generateSignature(params);
      
      const headers = {
          'Content-Type': 'application/json',
          'X-API-Key': this.apiKey,
          'X-Signature': signature,
          'X-Timestamp': timestamp
      };

      const config = {
          method: method,
          headers: headers
      };

      if (data && method !== 'GET') {
          config.body = JSON.stringify(data);
      } else if (data && method === 'GET') {
          // Для GET запросов параметры добавляются в URL
          const urlParams = new URLSearchParams(data).toString();
          endpoint += `?${urlParams}`;
      }

      try {
          const response = await fetch(url, config);
          
          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          }
          
          return await response.json();
      } catch (error) {
          console.error('API Request failed:', error);
          return null;
      }
  }

  // Примеры методов API
  async getStudents(filters = {}) {
      return await this.makeRequest('students', 'GET', filters);
  }

  async createStudent(studentData) {
      return await this.makeRequest('students', 'POST', studentData);
  }

  async getCourses() {
      return await this.makeRequest('courses', 'GET');
  }

  async getStudentProgress(studentId) {
      return await this.makeRequest(`students/${studentId}/progress`, 'GET');
  }

  async updateStudent(studentId, updateData) {
      return await this.makeRequest(`students/${studentId}`, 'PUT', updateData);
  }

  async deleteStudent(studentId) {
      return await this.makeRequest(`students/${studentId}`, 'DELETE');
  }
}

// Использование API
const API_KEY = 'wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4';

// Пример использования
async function exampleUsage() {
  const api = new ITCompotSchoolAPI(API_KEY);
  
  try {
      // Получить список студентов
      const students = await api.getStudents();
      console.log('Студенты:', students);
      
      // Получить курсы
      const courses = await api.getCourses();
      console.log('Курсы:', courses);
      
      // Создать нового студента
      const newStudent = {
          name: 'Иван Иванов',
          email: 'ivan@example.com',
          course_id: 1
      };
      // const createdStudent = await api.createStudent(newStudent);
      // console.log('Создан студент:', createdStudent);
      
  } catch (error) {
      console.error('Ошибка:', error);
  }
}

// Запуск примера
exampleUsage();

// Для использования в браузере
export default ITCompotSchoolAPI;