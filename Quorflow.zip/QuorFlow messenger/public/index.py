from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import json
import os
import API


 from '@messenger/api'

auth.init({
  clientId: 'wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4',
  scope: '300' '239',
})
#  хранения данных
DATA_FILE = 'package.json'

def load_data():
    """Загрузка данных из файла"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"chats": [], "messages": {}}

def save_data(data):
    """Сохранение данных в файл"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_next_chat_id(data):
    """Получение следующего ID для чата"""
    if not data["chats"]:
        return 1
    return max(chat["id"] for chat in data["chats"]) + 1

def get_next_message_id(data, chat_id):
    """Получение следующего ID для сообщения в чате"""
    messages = data["messages"].get(str(chat_id), [])
    if not messages:
        return 1
    return max(msg["id"] for msg in messages) + 1

@app.route('/chats', methods=['GET'])
def get_chats():
    """Получение списка всех чатов"""
    data = load_data()
    
    #  последнее сообщение для каждого чата
    chats_with_last_message = []
    for chat in data["chats"]:
        chat_copy = chat.copy()
        messages = data["messages"].get(str(chat["id"]), [])
        if messages:
            last_message = messages[-1]["text"]
            chat_copy["last_message"] = last_message[:50] + "..." if len(last_message) > 50 else last_message
        else:
            chat_copy["last_message"] = "Нет сообщений"
        chats_with_last_message.append(chat_copy)
    
    return jsonify(chats_with_last_message)

@app.route('/chats', methods=['POST'])
def create_chat():
    """Создание нового чата"""
    data = load_data()
    
    new_chat = {
        "id": get_next_chat_id(data),
        "name": request.json.get("name", "Новый чат"),
        "created_at": datetime.now().isoformat()
    }
    
    data["chats"].append(new_chat)
    save_data(data)
    
    return jsonify(new_chat), 201

@app.route('/chats/<int:chat_id>/messages', methods=['GET'])
def get_messages(chat_id):
    """Получение сообщений чата"""
    data = load_data()
    messages = data["messages"].get(str(chat_id), [])
    return jsonify(messages)

@app.route('/chats/<int:chat_id>/messages', methods=['POST'])
def add_message(chat_id):
    """Добавление сообщения в чат"""
    data = load_data()
    
    # проверка существование чата
    chat_exists = any(chat["id"] == chat_id for chat in data["chats"])
    if not chat_exists:
        return jsonify({"error": "Чат не найден"}), 404
    
    new_message = {
        "id": get_next_message_id(data, chat_id),
        "text": request.json.get("text", ""),
        "sender": request.json.get("sender", "user"),
        "timestamp": datetime.now().isoformat()
    }
    
    # Добавляем сообщение
    if str(chat_id) not in data["messages"]:
        data["messages"][str(chat_id)] = []
    data["messages"][str(chat_id)].append(new_message)
    save_data(data)
    
    # Автоматический ответ (имитация собеседника)
    if new_message["sender"] == "user":
        auto_reply = {
            "id": get_next_message_id(data, chat_id),
            "text": f"Я получил ваше сообщение: '{new_message['text']}'",
            "sender": "bot",
            "timestamp": datetime.now().isoformat()
        }
        data["messages"][str(chat_id)].append(auto_reply)
        save_data(data)
    
    return jsonify(new_message), 201

@app.route('/health', methods=['GET'])
def health_check():
    """Проверка здоровья сервера"""
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    # Создаем начальные данные если их нет
    if not os.path.exists(DATA_FILE):
        initial_data = {
            "chats": [
                {
                    "id": 1,
                    "name": "Общий чат",
                    "created_at": datetime.now().isoformat()
                }
            ],
            "messages": {
                "1": [
                    {
                        "id": 1,
                        "text": "Добро пожаловать в мессенджер!",
                        "sender": "bot",
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        }
        save_data(initial_data)
    
    app.run(debug=True, port=5000)
    from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

# Файл для хранения данных
DATA_FILE = 'data.json'

def load_data():
    """Загрузка данных из файла"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"chats": [], "messages": {}}

def save_data(data):
    """Сохранение данных в файл"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_next_chat_id(data):
    """Получение следующего ID для чата"""
    if not data["chats"]:
        return 1
    return max(chat["id"] for chat in data["chats"]) + 1

def get_next_message_id(data, chat_id):
    """Получение следующего ID для сообщения в чате"""
    messages = data["messages"].get(str(chat_id), [])
    if not messages:
        return 1
    return max(msg["id"] for msg in messages) + 1

@app.route('/')
def serve_index():
    """Обслуживание главной страницы"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Обслуживание статических файлов"""
    return send_from_directory('.', path)

@app.route('/api/chats', methods=['GET'])
def get_chats():
    """Получение списка всех чатов"""
    data = load_data()
    
    # Добавляем последнее сообщение для каждого чата
    chats_with_last_message = []
    for chat in data["chats"]:
        chat_copy = chat.copy()
        messages = data["messages"].get(str(chat["id"]), [])
        if messages:
            last_message = messages[-1]["text"]
            chat_copy["last_message"] = last_message[:50] + "..." if len(last_message) > 50 else last_message
        else:
            chat_copy["last_message"] = "Нет сообщений"
        chats_with_last_message.append(chat_copy)
    
    return jsonify(chats_with_last_message)

@app.route('/api/chats', methods=['POST'])
def create_chat():
    """Создание нового чата"""
    data = load_data()
    
    new_chat = {
        "id": get_next_chat_id(data),
        "name": request.json.get("name", "Новый чат"),
        "created_at": datetime.now().isoformat()
    }
    
    data["chats"].append(new_chat)
    save_data(data)
    
    return jsonify(new_chat), 201

@app.route('/api/chats/<int:chat_id>/messages', methods=['GET'])
def get_messages(chat_id):
    """Получение сообщений чата"""
    data = load_data()
    messages = data["messages"].get(str(chat_id), [])
    return jsonify(messages)

@app.route('/api/chats/<int:chat_id>/messages', methods=['POST'])
def add_message(chat_id):
    """Добавление сообщения в чат"""
    data = load_data()
    
    # Проверяем существование чата
    chat_exists = any(chat["id"] == chat_id for chat in data["chats"])
    if not chat_exists:
        return jsonify({"error": "Чат не найден"}), 404
    
    new_message = {
        "id": get_next_message_id(data, chat_id),
        "text": request.json.get("text", ""),
        "sender": request.json.get("sender", "user"),
        "timestamp": datetime.now().isoformat()
    }
    
    # Добавляем сообщение
    if str(chat_id) not in data["messages"]:
        data["messages"][str(chat_id)] = []
    data["messages"][str(chat_id)].append(new_message)
    save_data(data)
    
    # Автоматический ответ (имитация собеседника)
    if new_message["sender"] == "user":
        auto_reply = {
            "id": get_next_message_id(data, chat_id),
            "text": f"Привет! Я получил ваше сообщение: '{new_message['text']}'. Это автоматический ответ.",
            "sender": "bot",
            "timestamp": datetime.now().isoformat()
        }
        data["messages"][str(chat_id)].append(auto_reply)
        save_data(data)
    
    return jsonify(new_message), 201

@app.route('/api/health', methods=['GET'])
def health_check():
    """Проверка здоровья сервера"""
    return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()})

if __name__ == '__main__':
    # Создаем начальные данные если их нет
    if not os.path.exists(DATA_FILE):
        initial_data = {
            "chats": [
                {
                    "id": 1,
                    "name": "Общий чат",
                    "created_at": datetime.now().isoformat()
                },
                {
                    "id": 2,
                    "name": "Техподдержка",
                    "created_at": datetime.now().isoformat()
                }
            ],
            "messages": {
                "1": [
                    {
                        "id": 1,
                        "text": "Добро пожаловать в мессенджер!",
                        "sender": "bot",
                        "timestamp": datetime.now().isoformat()
                    },
                    {
                        "id": 2,
                        "text": "Начните общение, отправив сообщение",
                        "sender": "bot", 
                        "timestamp": datetime.now().isoformat()
                    }
                ],
                "2": [
                    {
                        "id": 1,
                        "text": "Чат технической поддержки",
                        "sender": "bot",
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        }
        save_data(initial_data)
        print("Созданы начальные данные")
    
    python server.py
    print("Запуск сервера мессенджера...")
    print("Откройте: host://2001:4860:4860::8888")
    app.run(debug=True, port=5000, host='8.8.8.8')
   
from .internet import InternetComponent, InternetManager

__all__ = ['InternetComponent', 'InternetManager']