const crypto = require('crypto');

class ITCompotSchoolAPI {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.baseUrl = 'wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4';
    }

    generateSignature(params) {
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const dataToSign = `${JSON.stringify(params)}${timestamp}${this.apiKey}`;
        const signature = crypto.createHash('sha256').update(dataToSign).digest('hex');
        return { signature, timestamp };
    }

    async makeRequest(endpoint, method = 'GET', data = null) {
        const url = `${this.baseUrl}/${endpoint}`;
        
        const params = data || {};
        const { signature, timestamp } = this.generateSignature(params);
        
        const headers = {
            'Content-Type': 'application/json',
            'X-API-Key': this.apiKey,
            'X-Signature': signature,
            'X-Timestamp': timestamp
        };

        const config = {
            method: method,
            headers: headers
        };

        if (data && method !== 'GET') {
            config.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Request failed:', error);
            return null;
        }
    }

    // Методы API остаются такими же как в предыдущем примере
    async getStudents(filters = {}) {
        return await this.makeRequest('students', 'GET', filters);
    }

    async createStudent(studentData) {
        return await this.makeRequest('students', 'POST', studentData);
    }

    async getCourses() {
        return await this.makeRequest('courses', 'GET');
    }

    async getStudentProgress(studentId) {
        return await this.makeRequest(`students/${studentId}/progress`, 'GET');
    }
}

// Использование
const API_KEY = 'wc_api_itcompotshool_c40a2398251570f2a7c5b9e0f74c09a4';
const api = new ITCompotSchoolAPI(API_KEY);

module.exports = ITCompotSchoolAPI;